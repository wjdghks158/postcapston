import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-match',
  templateUrl: './update-match.component.html',
  styleUrls: ['./update-match.component.css']
})
export class UpdateMatchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
