import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rank-recommend',
  templateUrl: './rank-recommend.component.html',
  styleUrls: ['./rank-recommend.component.css']
})
export class RankRecommendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
