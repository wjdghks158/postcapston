export interface ChatMessage {
    userName: string;
    content: string;
  }